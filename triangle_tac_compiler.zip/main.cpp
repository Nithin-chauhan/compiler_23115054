#include <iostream>
extern int yyparse();

int main() {
    std::cout << "Enter triangle sides (e.g. triangle(3, 4, 5);):\n";
    return yyparse();
}
